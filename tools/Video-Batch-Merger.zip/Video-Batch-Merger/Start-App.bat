@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python is needed once. Open PowerShell and run:
  echo winget install --id Python.Python.3.13 -e
  echo Then close this window and run Start-App.bat again.
  pause
  exit /b 1
)
set "MERGER_VENV=%LOCALAPPDATA%\VideoBatchMerger\venv"
if not exist "%MERGER_VENV%\Scripts\python.exe" (
  py -3 -m venv "%MERGER_VENV%"
  if errorlevel 1 goto failed
)
"%MERGER_VENV%\Scripts\python.exe" -m pip install --disable-pip-version-check -r "%~dp0requirements.txt"
if errorlevel 1 goto failed
"%MERGER_VENV%\Scripts\python.exe" "%~dp0app.py"
if errorlevel 1 goto failed
exit /b 0
:failed
 echo Setup or launch failed. Check the message above.
 pause
 exit /b 1
